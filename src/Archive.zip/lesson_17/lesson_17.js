import './lesson_17.scss';
import { SlideShow } from './slideshow';
import { SlideShowNew } from './slideshowClasses';

const mySlideShow = new SlideShow(
  document.querySelector('.here-will-be-slider')
);
mySlideShow.init();
window.mySlideShow = mySlideShow;
const mySlideShow2 = new SlideShowNew(document.querySelector('#test'));
mySlideShow2.init();
window.mySlideShow2 = mySlideShow2;
