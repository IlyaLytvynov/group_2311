import './lesson_13.scss';
import './traffic-lighter.scss';

const trafficLighterRoot = document.querySelector('.traffic-lighter');
const lights = trafficLighterRoot.querySelectorAll('.traffic-lighter__light');

for()
