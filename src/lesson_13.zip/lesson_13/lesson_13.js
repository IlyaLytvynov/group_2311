import './lesson_13.scss';
import { trafficLighter } from '../common/traffic-lighter/traffic-lighter';

trafficLighter('.first-lighter');
trafficLighter('.second-lighter');
trafficLighter('.third-lighter');
